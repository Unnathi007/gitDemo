import unittest
import test_task1
loader = unittest.TestLoader()

suite = unittest.TestSuite()

suite.addTests(loader.loadTestsFromModule(test_task1))
runner = unittest.TextTestRunner(verbosity=1)


test_results = runner.run(suite)

total_ran = test_results.testsRun
total_skipped = len(test_results.skipped)
total_errors = len(test_results.errors)
total_failed = len(test_results.failures)


print("Total Ran        : " + str(total_ran))
print("Total skipped     : " + str(total_skipped))
print("Total failed     : " + str(total_failed))
