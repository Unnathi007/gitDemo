import string

class Password:

    def __init__(self, password):
        self.pwd = password
        self.alpha_lower = set(string.ascii_lowercase)
        self.alpha_upper = set(string.ascii_uppercase)

    def lowerAlphaCheck(self):
        com_list = list(self.alpha_lower.intersection(set(self.pwd)))
        return len(com_list) > 0

    def upperAlphaCheck(self):
        com_list = list(self.alpha_upper.intersection(set(self.pwd)))
        return len(com_list) > 0

    def numericCheck(self):
        num_set = set(str(i) for i in range(10))
        com_list = list(num_set.intersection(set(self.pwd)))
        return len(com_list) > 0

    def charCheck(self):
        com_list = list(set(self.pwd).intersection(('$', '@', '#', '!')))
        return len(com_list) > 0

    def lengthCheck(self):
        return 6 <= len(self.pwd) <= 12


if __name__ == "__main__":
    user_input = input("Enter the strings with commas seperated : ")
    user_input_list = user_input.split(',')

    for pwd in user_input_list:
        PwdCheckObj = Password(pwd)
        lowerCheck = PwdCheckObj.lowerAlphaCheck()
        upperCheck = PwdCheckObj.upperAlphaCheck()
        charCheck = PwdCheckObj.charCheck()
        numCheck = PwdCheckObj.numericCheck()
        lenCheck = PwdCheckObj.lengthCheck()

        # print([lowerCheck, upperCheck, charCheck, numCheck, lenCheck])

        if all([lowerCheck, upperCheck, charCheck, numCheck, lenCheck]):
            print(pwd)
