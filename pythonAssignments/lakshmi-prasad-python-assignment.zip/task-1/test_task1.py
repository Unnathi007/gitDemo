import unittest
from task1 import Password


class TestPasswordCase(unittest.TestCase):

    def test_lowerAlphaCheck(self):
        obj = Password("ABd1234@1")
        check = obj.lowerAlphaCheck()
        self.assertEqual(check, True)

    def test_upperAlphaCheck(self):
        obj = Password("ABd1234@1")
        check = obj.upperAlphaCheck()
        self.assertEqual(check, True)

    def test_numericCheck(self):
        obj = Password("ABd1234@1")
        check = obj.numericCheck()
        self.assertEqual(check, True)

    def test_charCheck(self):
        obj = Password("ABd1234@1")
        check = obj.numericCheck()
        self.assertEqual(check, True)

    def test_lengthCheck(self):
        obj = Password("ABd1234@1")
        check = obj.numericCheck()
        self.assertEqual(check, True)
