import json


class FileOperations:
    def __init__(self) -> None:
        with open("employees.json", 'r') as file:
            self.data = json.load(file)

    def _write_json(self):
        try:
            with open("employees.json", "w") as file:
                json.dump(self.data, file)

        except Exception as err:
            print(err, "\nUnable to overwrite employees json file")


class Employee(FileOperations):
    def __init__(self) -> None:
        super().__init__()

    def _get_user_input(self, desc):
        while True:
            inp = input(desc)
            if inp != "":
                return inp.strip()

    def _get_employee(self, emp_id):
        if emp_id in self.data:
            return (True, self.data[emp_id])
        else:
            return (False, {})

    def add_employee(self):
        emp_id = self._get_user_input("Enter Employee ID : ")
        found, _ = self._get_employee(emp_id)

        if found:
            print("\n\nEmployee already Exists !!!")
            return False

        emp_name = self._get_user_input("Enter employee name : ")
        emp_dept = self._get_user_input("Enter employee department : ")

        try:
            self.data[emp_id] = {"name": emp_name,
                                 "dept": emp_dept}
            self._write_json()

            print("\n Employee added to Directory Successfully")

        except Exception as err:
            print("Error occured while adding new employee")
            return False

    def display_employee(self):
        emp_id = self._get_user_input("Enter Employee ID : ")

        found, emp_data = self._get_employee(emp_id)
        if found:
            name = emp_data["name"]
            dept = emp_data["dept"]
            print(f"Employee Name : {name}")
            print(f"Employee Department : {dept}")

        else:
            print("Employee not found")

    def remove_employee(self):
        emp_id = self._get_user_input("Enter Employee ID : ")
        found, _ = self._get_employee(emp_id)

        if found:
            try:
                del self.data[emp_id]
                self._write_json()
                print("Deleted successfully")

            except:
                print("Unable to delete the employee !!!")

        else:
            print("Employee not found in Directory")

    def update_employee(self):
        emp_id = self._get_user_input("Enter employee ID : ")
        found, _ = self._get_employee(emp_id)

        if not found:
            print("Employee Does not Exist to Update !!")
            return 0
        
        emp_name = self._get_user_input("Enter employee name : ")
        emp_dept = self._get_user_input("Enter employee department : ")

        try:
            self.data[emp_id] = {"name": emp_name,
                                 "dept": emp_dept}
            self._write_json()
            print("Details updated Successfully")
        
        except Exception as err:
            print("Unable to update Directory")

if __name__ == "__main__":
    menu = {
        1: "    1. Add an Employee",
        2: "    2. View Employee details",
        3: "    3. Remove an Employee",
        4: "    4. To update employee info",
        5: "    5. Exit"
    }

    while True:

        # Display Menu
        print("\nMENU \n---------")
        print("\n".join(menu.values()))

        # Creating employee object
        emp = Employee()

        # user inputs
        usr_inp = input("\nChoose an option from menu : ")

        # user input validation
        # If invalid -> retry
        try:
            usr_inp = int(usr_inp)

        except Exception as exp:
            print("Invalid input !!\nTry Again")
            continue

        # switch case based on user input
        match usr_inp:
            case 1: emp.add_employee()
            case 2: emp.display_employee()
            case 3: emp.remove_employee()
            case 4: emp.update_employee()
            case 5: break
            case _: print("\nInvalid Input !!! Try again")

    print("Good Bye !!!")
