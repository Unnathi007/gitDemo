from driver import FileOperations

obj = FileOperations()
print(obj.data)
while True:
    emp_id = input("Enter emp ID : ")
    if emp_id != "":
        break
