from task3 import *
import pyexcel
from datetime import datetime
import os


def test_get_date():
    date = get_date()
    assert date == '25_Nov_2022'


def test_csv_handle():
    check = csv_handle()
    assert check


def test_file_existance():
    assert os.path.exists('25_Nov_2022.xlsx')


def test_file_size():
    assert os.path.getsize('25_Nov_2022.xlsx') > 0
