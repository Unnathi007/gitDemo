import csv
import json


def convert_csv_to_json():
    with open("realestate.csv", "r", encoding="UTF-8") as fr:
        reader = csv.reader(fr)
        data = {}
        i = 0
        l = next(reader)
        for line in reader:
            row = {}
            for col in range(len(l)):
                row[l[col]] = line[col]

            data[f"row {i}"] = row
            i += 1

    with open("realestate.json", "w") as fw:
        json.dump(data, fw, indent=4)


if __name__ == "__main__":
    convert_csv_to_json()
