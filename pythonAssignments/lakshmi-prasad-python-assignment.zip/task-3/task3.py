import pyexcel
from datetime import datetime


def get_date():
    formatted_dt = datetime.now().strftime('%d_%b_%Y')
    return formatted_dt


def csv_handle():
    sheet = pyexcel.get_sheet(file_name="realestate.csv", delimiter=",")
    try:
        date = get_date()
        sheet.save_as(f"{date}.xlsx")
        print("SUCCESSFULL !!!")
        return True

    except Exception as err:
        print(err, "UNSUCCESSFULL !!!")
        return False


if __name__ == "__main__":
    csv_handle()
