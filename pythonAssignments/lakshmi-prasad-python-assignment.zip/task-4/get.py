import csv
from socket import gethostbyname as getIP

filename = 'hosts.csv'


def csv_reader(filename):
    for row in open(filename, "r"):
        # print(row.split(',')[1])
        yield row.split(',')


writer = open('hostswithip.csv', 'a')


def xlsx_writer(serial, host, ip):
    writer.write(",".join([serial, host, ip]))
    writer.write("\n")


for line in csv_reader(filename):
    try:
        if line[1].endswith(".com\n"):
            ip = getIP("www."+line[1].strip('\n'))
            host = "www." + line[1].strip('\n')
            serial = line[0]
            xlsx_writer(serial, host, ip)

    except Exception as err:
        print(err)
        print("--"*20, line)

writer.close()