from socket import gethostbyname as getIP
site = 'b2clogin.com'

print(getIP(site))
