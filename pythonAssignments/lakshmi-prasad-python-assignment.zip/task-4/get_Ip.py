import csv
from socket import gethostbyname as getIP

filename = 'hosts.csv'


def csv_reader(filename):
    for row in open(filename, "r"):
        # print(row.split(',')[1])
        yield row


for line in csv_reader(filename):
    if line.endswith(".com"):
        print(line)
